from sqlalchemy.orm import Session
from fastapi import HTTPException, status
from ..models import orders as model


def create(db: Session, request):
    new_order = model.Order(
        customer_name=request.customer_name,
        description=request.description
    )

    db.add(new_order)
    db.commit()
    db.refresh(new_order)

    return new_order


def read_all(db: Session):
    return db.query(model.Order).all()


def read_one(db: Session, item_id: int):
    order = db.query(model.Order).filter(model.Order.id == item_id).first()

    if not order:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Order not found"
        )

    return order


def update(db: Session, item_id: int, request):
    order = db.query(model.Order).filter(model.Order.id == item_id).first()

    if not order:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Order not found"
        )

    update_data = request.dict(exclude_unset=True)

    for key, value in update_data.items():
        setattr(order, key, value)

    db.commit()
    db.refresh(order)

    return order


def delete(db: Session, item_id: int):
    order = db.query(model.Order).filter(model.Order.id == item_id).first()

    if not order:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Order not found"
        )

    db.delete(order)
    db.commit()